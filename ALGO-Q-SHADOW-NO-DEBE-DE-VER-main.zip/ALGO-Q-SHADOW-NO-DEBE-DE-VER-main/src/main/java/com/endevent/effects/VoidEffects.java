package com.endevent.effects;

import com.endevent.VoidEventPlugin;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

public class VoidEffects {

    private final VoidEventPlugin plugin;
    private final List<BukkitTask> activeTasks = new ArrayList<>();

    public VoidEffects(VoidEventPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Dibuja un círculo de partículas de colores con múltiples capas, gradientes
     * suaves, anillo interior/exterior, runas flotantes y destellos.
     */
    public BukkitTask spawnColorCircle(Location center, double radius, int points) {
        BukkitTask task = new BukkitRunnable() {
            double rotation = 0;
            int tick = 0;
            @Override
            public void run() {
                World world = center.getWorld();
                tick++;

                // ── Anillo exterior principal: gradiente suave continuo ──
                for (int i = 0; i < points; i++) {
                    double angle = (2 * Math.PI / points) * i + rotation;
                    double x = center.getX() + radius * Math.cos(angle);
                    double z = center.getZ() + radius * Math.sin(angle);
                    Location point = new Location(world, x, center.getY(), z);

                    Color color = getCircleColorSmooth(angle + rotation);
                    Particle.DustOptions dust = new Particle.DustOptions(color, 1.8f);
                    world.spawnParticle(Particle.DUST, point, 2, 0.05, 0.02, 0.05, 0, dust);

                    if (i % 4 == 0) {
                        world.spawnParticle(Particle.PORTAL, point, 1, 0.1, 0.4, 0.1, 0.05);
                    }
                }

                // ── Anillo interior (radio 60%): gira en sentido contrario ──
                double innerRadius = radius * 0.6;
                int innerPoints = (int)(points * 0.6);
                for (int i = 0; i < innerPoints; i++) {
                    double angle = (2 * Math.PI / innerPoints) * i - rotation * 1.5;
                    double x = center.getX() + innerRadius * Math.cos(angle);
                    double z = center.getZ() + innerRadius * Math.sin(angle);
                    Location point = new Location(world, x, center.getY() + 0.1, z);

                    Color color = getCircleColorSmooth(angle - rotation);
                    Particle.DustOptions dust = new Particle.DustOptions(color, 1.3f);
                    world.spawnParticle(Particle.DUST, point, 1, 0.03, 0.02, 0.03, 0, dust);
                }

                // ── Runas flotantes: 6 símbolos que orbitan entre los anillos ──
                double runeRadius = radius * 0.8;
                for (int r = 0; r < 6; r++) {
                    double runeAngle = (2 * Math.PI / 6) * r + rotation * 0.7;
                    double rx = center.getX() + runeRadius * Math.cos(runeAngle);
                    double rz = center.getZ() + runeRadius * Math.sin(runeAngle);
                    double ry = center.getY() + 0.3 + Math.sin(tick * 0.08 + r) * 0.3;
                    Location runeLoc = new Location(world, rx, ry, rz);

                    // Mini-cruz de partículas como "runa"
                    Particle.DustOptions rune = new Particle.DustOptions(Color.fromRGB(255, 200, 255), 1.2f);
                    world.spawnParticle(Particle.DUST, runeLoc, 1, 0, 0, 0, 0, rune);
                    world.spawnParticle(Particle.DUST, runeLoc.clone().add(0.15, 0, 0), 1, 0, 0, 0, 0, rune);
                    world.spawnParticle(Particle.DUST, runeLoc.clone().add(-0.15, 0, 0), 1, 0, 0, 0, 0, rune);
                    world.spawnParticle(Particle.DUST, runeLoc.clone().add(0, 0.15, 0), 1, 0, 0, 0, 0, rune);
                    world.spawnParticle(Particle.DUST, runeLoc.clone().add(0, -0.15, 0), 1, 0, 0, 0, 0, rune);
                    world.spawnParticle(Particle.ENCHANT, runeLoc, 2, 0.1, 0.2, 0.1, 0.3);
                }

                // ── Rayos radiales: líneas desde el centro hacia el borde cada 45° ──
                if (tick % 3 == 0) {
                    for (int r = 0; r < 8; r++) {
                        double rayAngle = (Math.PI / 4) * r + rotation * 0.5;
                        for (double d = innerRadius; d < radius; d += 0.6) {
                            Location ray = new Location(world,
                                    center.getX() + d * Math.cos(rayAngle),
                                    center.getY() + 0.05,
                                    center.getZ() + d * Math.sin(rayAngle));
                            Particle.DustOptions rayDust = new Particle.DustOptions(
                                    Color.fromRGB(180, 120, 255), 0.8f);
                            world.spawnParticle(Particle.DUST, ray, 1, 0, 0, 0, 0, rayDust);
                        }
                    }
                }

                // ── Destellos aleatorios dentro del círculo ──
                if (tick % 2 == 0) {
                    for (int s = 0; s < 3; s++) {
                        double sAngle = Math.random() * 2 * Math.PI;
                        double sR = Math.random() * radius;
                        Location sparkle = new Location(world,
                                center.getX() + sR * Math.cos(sAngle),
                                center.getY() + 0.2 + Math.random() * 0.5,
                                center.getZ() + sR * Math.sin(sAngle));
                        world.spawnParticle(Particle.END_ROD, sparkle, 1, 0, 0.05, 0, 0.01);
                    }
                }

                rotation += 0.025;
            }
        }.runTaskTimer(plugin, 0L, 2L);
        activeTasks.add(task);
        return task;
    }

    /** Gradiente de color suave basado en ángulo (HSB-like cycle) */
    public Color getCircleColorSmooth(double angle) {
        // Normalizar ángulo a [0, 2π]
        angle = ((angle % (2 * Math.PI)) + 2 * Math.PI) % (2 * Math.PI);
        double ratio = angle / (2 * Math.PI);

        // Ciclo: morado → azul → cyan → magenta → morado (interpolación suave)
        int r, g, b;
        if (ratio < 0.25) {
            double t = ratio / 0.25;
            r = (int)(128 * (1 - t));
            g = (int)(100 * t);
            b = 255;
        } else if (ratio < 0.5) {
            double t = (ratio - 0.25) / 0.25;
            r = 0;
            g = (int)(100 + 100 * t);
            b = 255;
        } else if (ratio < 0.75) {
            double t = (ratio - 0.5) / 0.25;
            r = (int)(200 * t);
            g = (int)(200 * (1 - t * 0.5));
            b = (int)(255 * (1 - t * 0.3));
        } else {
            double t = (ratio - 0.75) / 0.25;
            r = (int)(200 - 72 * t);
            g = (int)(100 * (1 - t));
            b = (int)(178 + 77 * t);
        }
        return Color.fromRGB(
                Math.max(0, Math.min(255, r)),
                Math.max(0, Math.min(255, g)),
                Math.max(0, Math.min(255, b)));
    }

    /**
     * Dibuja un rayo/linea de particulas entre dos puntos
     */
    public void drawBeam(Location from, Location to, Particle particle, int density) {
        drawBeam(from, to, particle, density, null);
    }

    public <T> void drawBeam(Location from, Location to, Particle particle, int density, T data) {
        World world = from.getWorld();
        Vector direction = to.toVector().subtract(from.toVector());
        double distance = direction.length();
        direction.normalize();

        for (int i = 0; i < density; i++) {
            double t = (double) i / density;
            Location point = from.clone().add(direction.clone().multiply(distance * t));
            if (data != null) {
                world.spawnParticle(particle, point, 1, 0.02, 0.02, 0.02, 0, data);
            } else {
                world.spawnParticle(particle, point, 1, 0.02, 0.02, 0.02, 0);
            }
        }
    }

    /**
     * Rayo negro (oscuro) desde un punto a otro — con núcleo denso, halo morado y chisporroteo
     */
    public void drawDarkBeam(Location from, Location to, int density) {
        World world = from.getWorld();
        Vector direction = to.toVector().subtract(from.toVector());
        double distance = direction.length();
        direction.normalize();

        for (int i = 0; i < density; i++) {
            double t = (double) i / density;
            Location point = from.clone().add(direction.clone().multiply(distance * t));

            // Núcleo negro denso
            Particle.DustOptions blackDust = new Particle.DustOptions(Color.fromRGB(10, 0, 20), 1.5f);
            world.spawnParticle(Particle.DUST, point, 2, 0.02, 0.02, 0.02, 0, blackDust);
            // Halo morado alrededor
            if (i % 2 == 0) {
                Particle.DustOptions purpleDust = new Particle.DustOptions(Color.fromRGB(100, 0, 160), 1.0f);
                world.spawnParticle(Particle.DUST, point, 1, 0.08, 0.08, 0.08, 0, purpleDust);
            }
            // Chisporroteo eléctrico aleatorio
            if (Math.random() < 0.15) {
                double ox = (Math.random() - 0.5) * 0.4;
                double oy = (Math.random() - 0.5) * 0.4;
                double oz = (Math.random() - 0.5) * 0.4;
                world.spawnParticle(Particle.SOUL_FIRE_FLAME, point.clone().add(ox, oy, oz), 1, 0, 0, 0, 0.01);
            }
        }
    }

    /**
     * Rayo estilo cristal del End (rosado/blanco) con shimmer iridiscente
     */
    public void drawCrystalBeam(Location from, Location to, int density) {
        World world = from.getWorld();
        Vector direction = to.toVector().subtract(from.toVector());
        double distance = direction.length();
        direction.normalize();

        for (int i = 0; i < density; i++) {
            double t = (double) i / density;
            Location point = from.clone().add(direction.clone().multiply(distance * t));

            world.spawnParticle(Particle.END_ROD, point, 1, 0.02, 0.02, 0.02, 0);
            // Shimmer iridiscente que cambia de color a lo largo del rayo
            int r = (int)(200 + 55 * Math.sin(t * Math.PI * 4));
            int g = (int)(100 + 100 * Math.sin(t * Math.PI * 4 + 2));
            int b = (int)(200 + 55 * Math.sin(t * Math.PI * 4 + 4));
            Particle.DustOptions shimmer = new Particle.DustOptions(
                    Color.fromRGB(Math.min(255, Math.max(0, r)), Math.min(255, Math.max(0, g)), Math.min(255, Math.max(0, b))), 1.2f);
            world.spawnParticle(Particle.DUST, point, 1, 0.03, 0.03, 0.03, 0, shimmer);
        }
    }

    /**
     * Partículas de muerte del dragón — vórtice espiral ascendente con explosión final
     */
    public BukkitTask spawnDragonDeathParticles(Location center, int durationTicks) {
        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= durationTicks) {
                    cancel();
                    return;
                }
                World world = center.getWorld();
                double progress = (double) ticks / durationTicks;

                // Partículas aleatorias intensas
                int count = (int)(15 + progress * 30);
                for (int i = 0; i < count; i++) {
                    double rx = (Math.random() - 0.5) * (4 + progress * 3);
                    double ry = Math.random() * (6 + progress * 4);
                    double rz = (Math.random() - 0.5) * (4 + progress * 3);
                    Location p = center.clone().add(rx, ry, rz);
                    world.spawnParticle(Particle.DRAGON_BREATH, p, 1, 0, 0, 0, 0.02);
                    world.spawnParticle(Particle.END_ROD, p, 1, 0, 0.15, 0, 0.02);
                }

                // Doble anillo espiral ascendente
                double radius = 2.0 + progress * 4;
                int ringPoints = 30;
                for (int i = 0; i < ringPoints; i++) {
                    double angle = (2 * Math.PI / ringPoints) * i + ticks * 0.15;
                    double h1 = progress * 6 + Math.sin(angle * 3) * 0.5;
                    Location ring1 = center.clone().add(radius * Math.cos(angle), h1, radius * Math.sin(angle));
                    Location ring2 = center.clone().add(radius * 0.6 * Math.cos(-angle + ticks * 0.2), h1 * 0.7, radius * 0.6 * Math.sin(-angle + ticks * 0.2));
                    Particle.DustOptions purple = new Particle.DustOptions(Color.fromRGB(100, 0, 180), 1.8f);
                    Particle.DustOptions cyan = new Particle.DustOptions(Color.fromRGB(0, 150, 200), 1.2f);
                    world.spawnParticle(Particle.DUST, ring1, 1, 0.05, 0.05, 0.05, 0, purple);
                    if (i % 2 == 0) {
                        world.spawnParticle(Particle.DUST, ring2, 1, 0.05, 0.05, 0.05, 0, cyan);
                    }
                }
                world.spawnParticle(Particle.PORTAL, center.clone().add(0, progress * 3, 0), 5, 0.5, 1, 0.5, 0.8);

                // Columna de luz en los últimos ticks
                if (progress > 0.7) {
                    for (double h = 0; h < 10; h += 0.3) {
                        Particle.DustOptions light = new Particle.DustOptions(Color.fromRGB(200, 180, 255), 2.0f);
                        world.spawnParticle(Particle.DUST, center.clone().add(0, h, 0), 1, 0.2, 0, 0.2, 0, light);
                    }
                }
                ticks += 2;
            }
        }.runTaskTimer(plugin, 0L, 2L);
        activeTasks.add(task);
        return task;
    }

    /**
     * Explosión visual grande — con onda de choque expansiva, escombros y flash
     */
    public void bigExplosion(Location loc) {
        World world = loc.getWorld();
        // Flash central
        world.spawnParticle(Particle.EXPLOSION_EMITTER, loc, 3, 0.5, 0.5, 0.5, 0);
        world.spawnParticle(Particle.FLASH, loc, 2, 0, 0, 0, 0, Color.fromARGB(255, 255, 255, 220));
        world.spawnParticle(Particle.FLAME, loc, 60, 2.5, 2.5, 2.5, 0.15);
        world.spawnParticle(Particle.LAVA, loc, 25, 1.5, 1.5, 1.5, 0);
        world.spawnParticle(Particle.SOUL_FIRE_FLAME, loc, 20, 1.5, 1, 1.5, 0.08);

        // Onda de choque expandiéndose
        new BukkitRunnable() {
            double radius = 1;
            int t = 0;
            @Override
            public void run() {
                if (t++ >= 10) { cancel(); return; }
                radius += 1.8;
                int pts = (int)(radius * 12);
                for (int i = 0; i < pts; i++) {
                    double a = (2 * Math.PI / pts) * i;
                    Location p = loc.clone().add(radius * Math.cos(a), 0.3, radius * Math.sin(a));
                    Particle.DustOptions ring = new Particle.DustOptions(
                            Color.fromRGB(255, (int)(200 - t * 20), (int)(100 - t * 10)), 2.5f - t * 0.15f);
                    world.spawnParticle(Particle.DUST, p, 1, 0, 0, 0, 0, ring);
                }
                // Escombros volando hacia afuera
                for (int i = 0; i < 5; i++) {
                    double a = Math.random() * 2 * Math.PI;
                    Location debris = loc.clone().add(radius * 0.8 * Math.cos(a), Math.random() * 2, radius * 0.8 * Math.sin(a));
                    world.spawnParticle(Particle.SMOKE, debris, 2, 0.2, 0.3, 0.2, 0.05);
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    /**
     * Aura alrededor de un mob gigante — anillos orbitales, núcleo oscuro y rayos
     */
    public BukkitTask spawnGiantAura(org.bukkit.entity.Entity entity) {
        BukkitTask task = new BukkitRunnable() {
            int tick = 0;
            @Override
            public void run() {
                if (entity == null || entity.isDead()) {
                    cancel();
                    return;
                }
                tick++;
                Location loc = entity.getLocation().add(0, 6, 0);
                World world = entity.getWorld();

                // Partículas de niebla oscura aleatoria
                for (int i = 0; i < 12; i++) {
                    double rx = (Math.random() - 0.5) * 7;
                    double ry = (Math.random() - 0.5) * 14;
                    double rz = (Math.random() - 0.5) * 7;
                    Location p = loc.clone().add(rx, ry, rz);
                    Particle.DustOptions dust = new Particle.DustOptions(
                            Color.fromRGB(20 + (int)(Math.random() * 20), 0, 40 + (int)(Math.random() * 30)), 2.5f);
                    world.spawnParticle(Particle.DUST, p, 1, 0, 0, 0, 0, dust);
                }

                // Anillo orbital horizontal
                double orbRadius = 4 + Math.sin(tick * 0.06) * 1;
                for (int i = 0; i < 20; i++) {
                    double a = (2 * Math.PI / 20) * i + tick * 0.1;
                    Location orb = loc.clone().add(orbRadius * Math.cos(a), Math.sin(a * 3 + tick * 0.08) * 1.5, orbRadius * Math.sin(a));
                    Particle.DustOptions orbDust = new Particle.DustOptions(Color.fromRGB(80, 0, 130), 1.8f);
                    world.spawnParticle(Particle.DUST, orb, 1, 0, 0, 0, 0, orbDust);
                }

                // Anillo orbital vertical (perpendicular)
                for (int i = 0; i < 16; i++) {
                    double a = (2 * Math.PI / 16) * i - tick * 0.08;
                    Location vOrb = loc.clone().add(orbRadius * 0.8 * Math.cos(a), orbRadius * 0.8 * Math.sin(a), 0);
                    Particle.DustOptions vDust = new Particle.DustOptions(Color.fromRGB(50, 0, 90), 1.4f);
                    world.spawnParticle(Particle.DUST, vOrb, 1, 0, 0, 0, 0, vDust);
                }

                // Llamas del alma
                if (tick % 2 == 0) {
                    world.spawnParticle(Particle.SOUL_FIRE_FLAME, loc, 4, 2, 3, 2, 0.02);
                }

                // Rayos verticales periódicos
                if (tick % 15 == 0) {
                    for (double h = -6; h < 8; h += 0.4) {
                        Particle.DustOptions bolt = new Particle.DustOptions(Color.fromRGB(60, 0, 100), 1.5f);
                        world.spawnParticle(Particle.DUST, loc.clone().add(0, h, 0), 1, 0.1, 0, 0.1, 0, bolt);
                    }
                }
            }
        }.runTaskTimer(plugin, 0L, 2L);
        activeTasks.add(task);
        return task;
    }

    /**
     * Partículas de grietas en el suelo — grietas radiales con humo y lava
     */
    public void spawnCrackParticles(Location center, double radius) {
        World world = center.getWorld();
        // Grietas radiales
        int numCracks = 8 + (int)(Math.random() * 4);
        for (int c = 0; c < numCracks; c++) {
            double angle = (2 * Math.PI / numCracks) * c + (Math.random() - 0.5) * 0.3;
            for (double d = 0.5; d < radius; d += 0.3) {
                double wobble = (Math.random() - 0.5) * 0.4;
                double px = center.getX() + d * Math.cos(angle + wobble * 0.1);
                double pz = center.getZ() + d * Math.sin(angle + wobble * 0.1);
                Location p = new Location(world, px, center.getY() + 0.3, pz);
                // Color: rojo oscuro en el centro, negro en los bordes
                double t = d / radius;
                int red = (int)(120 * (1 - t));
                Particle.DustOptions dust = new Particle.DustOptions(Color.fromRGB(red, 0, 0), 1.5f + (float)(1 - t));
                world.spawnParticle(Particle.DUST, p, 2, 0.1, 0.05, 0.1, 0, dust);
                if (Math.random() < 0.2) {
                    world.spawnParticle(Particle.SMOKE, p, 1, 0.05, 0.3, 0.05, 0.03);
                }
                if (Math.random() < 0.05) {
                    world.spawnParticle(Particle.LAVA, p, 1, 0, 0, 0, 0);
                }
            }
        }
        // Partículas aleatorias de relleno
        for (int i = 0; i < 40; i++) {
            double a = Math.random() * 2 * Math.PI;
            double r = Math.random() * radius;
            Location p = center.clone().add(r * Math.cos(a), 0.4, r * Math.sin(a));
            world.spawnParticle(Particle.SMOKE, p, 1, 0.15, 0.2, 0.15, 0.02);
        }
    }

    /**
     * Partículas de renacimiento del dragón de luz — hélice ADN dorada con chispas ascendentes
     */
    public BukkitTask spawnLightBirthEffect(Location center, int durationTicks) {
        BukkitTask task = new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (ticks >= durationTicks) {
                    cancel();
                    return;
                }
                World world = center.getWorld();
                double progress = (double) ticks / durationTicks;
                double radius = 1 + progress * 5;

                // Doble hélice ascendente (estilo ADN)
                int helixPoints = 40;
                for (int i = 0; i < helixPoints; i++) {
                    double t = (double) i / helixPoints;
                    double angle = t * Math.PI * 6 + ticks * 0.15;
                    double h = t * (4 + progress * 8);
                    double r = radius * (0.5 + 0.5 * Math.sin(t * Math.PI));

                    // Hebra 1: dorada
                    Location h1 = center.clone().add(r * Math.cos(angle), h, r * Math.sin(angle));
                    Particle.DustOptions gold = new Particle.DustOptions(Color.fromRGB(255, 215, 0), 1.8f);
                    world.spawnParticle(Particle.DUST, h1, 1, 0.02, 0.02, 0.02, 0, gold);

                    // Hebra 2: blanca (desfasada 180°)
                    Location h2 = center.clone().add(r * Math.cos(angle + Math.PI), h, r * Math.sin(angle + Math.PI));
                    Particle.DustOptions white = new Particle.DustOptions(Color.fromRGB(255, 255, 240), 1.4f);
                    world.spawnParticle(Particle.DUST, h2, 1, 0.02, 0.02, 0.02, 0, white);

                    // Puentes entre hebras (cada 8 puntos)
                    if (i % 8 == 0) {
                        for (double bt = 0; bt < 1; bt += 0.2) {
                            Location bridge = h1.clone().add(
                                    (h2.getX() - h1.getX()) * bt, (h2.getY() - h1.getY()) * bt, (h2.getZ() - h1.getZ()) * bt);
                            Particle.DustOptions bDust = new Particle.DustOptions(Color.fromRGB(255, 240, 180), 0.8f);
                            world.spawnParticle(Particle.DUST, bridge, 1, 0, 0, 0, 0, bDust);
                        }
                    }
                }

                // Chispas ascendentes aleatorias
                for (int s = 0; s < (int)(5 + progress * 15); s++) {
                    double sa = Math.random() * 2 * Math.PI;
                    double sr = Math.random() * radius * 1.2;
                    double sy = Math.random() * progress * 10;
                    Location spark = center.clone().add(sr * Math.cos(sa), sy, sr * Math.sin(sa));
                    world.spawnParticle(Particle.END_ROD, spark, 1, 0, 0.15, 0, 0.03);
                }

                // Anillo base pulsante
                double baseR = radius * (0.8 + Math.sin(ticks * 0.2) * 0.2);
                for (int i = 0; i < 20; i++) {
                    double a = (2 * Math.PI / 20) * i + ticks * 0.05;
                    Location ring = center.clone().add(baseR * Math.cos(a), 0.2, baseR * Math.sin(a));
                    Particle.DustOptions ringDust = new Particle.DustOptions(Color.fromRGB(255, 200, 100), 1.5f);
                    world.spawnParticle(Particle.DUST, ring, 1, 0, 0, 0, 0, ringDust);
                }

                ticks += 2;
            }
        }.runTaskTimer(plugin, 0L, 2L);
        activeTasks.add(task);
        return task;
    }

    public void cancelAll() {
        activeTasks.forEach(t -> { if (!t.isCancelled()) t.cancel(); });
        activeTasks.clear();
    }
}
